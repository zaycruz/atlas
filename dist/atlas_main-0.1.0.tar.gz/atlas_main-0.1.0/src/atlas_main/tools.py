"""Tool registry and web search implementation for Atlas Lite."""
from __future__ import annotations

import asyncio
import difflib
import json
import os
import pty
import re
import select
import subprocess
import tempfile
import threading
import time
import shutil
import sys
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import requests

from .safety import redact_mapping, redact_text
from .telemetry import Telemetry
from .tools_browser import BrowserSession, DEFAULT_BUDGET, DEFAULT_TOPN
from .orchestrator.engine import Orchestrator
from .orchestrator.types import TaskSpec, StepSpec
from .agents import AgentFactory


USER_AGENT = "AtlasLite/1.0 (+https://github.com)"
DEFAULT_FILE_CHUNK = 6000
MAX_SHELL_OUTPUT = 4000


class ToolError(RuntimeError):
    """Raised when a tool cannot complete its task."""


def _resolve_user_path(raw_path: str) -> Path:
    if not raw_path or not raw_path.strip():
        raise ToolError("path is required")
    candidate = Path(raw_path).expanduser()
    try:
        return candidate.resolve(strict=False)
    except Exception as exc:  # pragma: no cover - platform specific errors
        raise ToolError(f"unable to resolve path: {exc}") from exc


@dataclass
class ToolDescription:
    name: str
    description: str
    args_hint: str


class Tool:
    """Base class for tools usable by the agent."""

    name: str = ""
    description: str = ""
    args_hint: str = ""
    capabilities: frozenset[str] = frozenset()
    parameters_schema: Dict[str, Any] = {
        "type": "object",
        "properties": {},
        "additionalProperties": True,
    }

    def describe(self) -> ToolDescription:
        return ToolDescription(self.name, self.description, self.args_hint)

    def run(self, *, agent=None, **kwargs: Any) -> str:  # pragma: no cover - interface
        raise NotImplementedError

    def function_parameters(self) -> Dict[str, Any]:
        return self.parameters_schema

    def capability_summary(self) -> str:
        if not self.capabilities:
            return "none"
        return ", ".join(sorted(self.capabilities))


class ToolPolicyManager:
    """Persisted allow/deny policy for tools."""

    def __init__(self) -> None:
        self.mode = os.getenv("ATLAS_TOOL_POLICY", "allow").strip().lower() or "allow"
        self.policy_path = Path(os.getenv("ATLAS_POLICY_PATH", "~/.atlas/policy.json")).expanduser()
        self.noninteractive_fallback = (
            os.getenv("ATLAS_TOOL_POLICY_NONINTERACTIVE", "allow").strip().lower() or "allow"
        )
        self._lock = threading.Lock()
        self._decisions: Dict[str, str] = self._load()

    def evaluate(self, tool: Tool, arguments: Dict[str, Any]) -> Tuple[bool, str]:
        """Return (allowed, decision_label)."""
        mode = self.mode
        if mode not in {"allow", "deny", "ask"}:
            mode = "allow"
        if mode == "allow":
            return True, "allow_default"
        if mode == "deny":
            return False, "deny_default"

        with self._lock:
            cached = self._decisions.get(tool.name)
        if cached == "allow":
            return True, "allow_cached"
        if cached == "deny":
            return False, "deny_cached"

        if not sys.stdin.isatty():
            fallback = "allow" if self.noninteractive_fallback != "deny" else "deny"
            return (fallback == "allow", f"{fallback}_noninteractive")

        decision = self._prompt(tool, arguments)
        if decision == "allow_always":
            self._set_decision(tool.name, "allow")
            return True, "allow_always"
        if decision == "deny_always":
            self._set_decision(tool.name, "deny")
            return False, "deny_always"
        if decision == "allow_once":
            return True, "allow_once"
        return False, "deny_once"

    def _prompt(self, tool: Tool, arguments: Dict[str, Any]) -> str:
        caps = tool.capability_summary()
        description = redact_text(tool.description or "(no description)")
        message = (
            f"\nTool '{tool.name}' requested.\n"
            f"Description: {description}\n"
            f"Capabilities: {caps}\n"
            f"Arguments: {self._summarize_arguments(arguments)}\n"
            "Allow this tool? [y]es once / [a]lways allow / [n]o once / [d]eny always: "
        )
        while True:
            try:
                choice = input(message).strip().lower()
            except EOFError:
                return "deny_once"
            if choice in {"y", "yes"}:
                return "allow_once"
            if choice in {"a", "always"}:
                return "allow_always"
            if choice in {"n", "no"}:
                return "deny_once"
            if choice in {"d", "deny"}:
                return "deny_always"
            print("Please respond with y/yes, a/always, n/no, or d/deny.")

    def _summarize_arguments(self, arguments: Dict[str, Any]) -> str:
        if not arguments:
            return "(none)"
        parts: List[str] = []
        for key, value in arguments.items():
            text = redact_text(str(value))
            if len(text) > 120:
                text = text[:117] + "..."
            parts.append(f"{key}={text}")
        return ", ".join(parts)

    def _set_decision(self, tool_name: str, decision: str) -> None:
        with self._lock:
            self._decisions[tool_name] = decision
            self._save()

    def _load(self) -> Dict[str, str]:
        if not self.policy_path.exists():
            return {}
        try:
            data = json.loads(self.policy_path.read_text())
            if isinstance(data, dict):
                return {str(k): str(v) for k, v in data.items()}
        except Exception:
            return {}
        return {}

    def _save(self) -> None:
        try:
            self.policy_path.parent.mkdir(parents=True, exist_ok=True)
            self.policy_path.write_text(json.dumps(self._decisions, indent=2))
        except Exception:
            pass


class ToolAuditLogger:
    """Append-only JSON lines audit log for tool executions."""

    def __init__(self) -> None:
        raw_path = os.getenv("ATLAS_AUDIT_LOG", "~/.atlas/audit.jsonl")
        self.log_path = Path(raw_path).expanduser()
        self.enabled = bool(raw_path)
        self._lock = threading.Lock()

    def log(
        self,
        *,
        tool: str,
        capabilities: Iterable[str],
        decision: str,
        status: str,
        duration: float,
        arguments: Dict[str, Any],
        args_digest: str,
        error: Optional[str] = None,
    ) -> None:
        if not self.enabled:
            return
        record = {
            "ts": datetime.utcnow().isoformat() + "Z",
            "tool": tool,
            "capabilities": sorted(set(capabilities)),
            "decision": decision,
            "status": status,
            "duration": round(duration, 3),
            "arguments": redact_mapping(arguments),
            "args_digest": args_digest,
        }
        if error:
            record["error"] = redact_text(error)
        try:
            line = json.dumps(record, ensure_ascii=False)
        except Exception:
            line = json.dumps(
                {key: str(value) for key, value in record.items()},
                ensure_ascii=False,
            )
        with self._lock:
            try:
                self.log_path.parent.mkdir(parents=True, exist_ok=True)
                with self.log_path.open("a", encoding="utf-8") as handle:
                    handle.write(line + "\n")
            except Exception:
                pass



class ToolRegistry:
    """Maintains available tools and executes them safely."""

    def __init__(self) -> None:
        self._tools: Dict[str, Tool] = {}
        self._policy = ToolPolicyManager()
        self._audit = ToolAuditLogger()

    def register(self, tool: Tool) -> None:
        self._tools[tool.name] = tool

    def render_instructions(self) -> str:
        lines: List[str] = []
        for tool in self._tools.values():
            desc = tool.describe()
            lines.append(f"- {desc.name}: {desc.description}")
            if desc.args_hint:
                lines.append(f"  args: {desc.args_hint}")
            if tool.capabilities:
                lines.append(f"  capabilities: {', '.join(sorted(tool.capabilities))}")
        return "\n".join(lines) if lines else "(no tools available)"

    def run(self, name: str, *, agent=None, arguments: Optional[Dict[str, Any]] = None) -> str:
        tool = self._tools.get(name)
        if not tool:
            raise ToolError(f"Unknown tool: {name}")
        args = arguments or {}
        allow, decision = self._policy.evaluate(tool, args)
        args_summary = self._safe_arguments(args)
        args_digest = self._arguments_digest(args)
        if not allow:
            self._audit.log(
                tool=tool.name,
                capabilities=tool.capabilities,
                decision=decision,
                status="denied",
                duration=0.0,
                arguments=args_summary,
                args_digest=args_digest,
                error="policy_denied",
            )
            raise ToolError(f"Tool '{name}' denied by policy")
        start_time = time.time()
        status = "success"
        error_message: Optional[str] = None
        result = ""
        try:
            result = tool.run(agent=agent, **args)
        except ToolError as exc:
            status = "error"
            error_message = str(exc)
            raise
        except Exception as exc:  # pragma: no cover - defensive
            status = "error"
            error_message = f"{type(exc).__name__}: {exc}"
            raise ToolError(f"Tool '{name}' failed: {exc}") from exc
        finally:
            duration = time.time() - start_time
            self._audit.log(
                tool=tool.name,
                capabilities=tool.capabilities,
                decision=decision,
                status=status,
                duration=duration,
                arguments=args_summary,
                args_digest=args_digest,
                error=error_message,
            )
            Telemetry.instance().observe_tool(tool.name, duration, status)
        return result

    def list_names(self) -> Iterable[str]:
        return list(self._tools.keys())

    def render_function_specs(self) -> List[Dict[str, Any]]:
        """Render tool metadata for function-calling capable models."""
        specs: List[Dict[str, Any]] = []
        for tool in self._tools.values():
            specs.append(
                {
                    "type": "function",
                    "function": {
                        "name": tool.name,
                        "description": tool.description,
                        "parameters": tool.function_parameters(),
                        "capabilities": sorted(tool.capabilities),
                    },
                }
            )
        return specs

    @staticmethod
    def _safe_arguments(arguments: Dict[str, Any]) -> Dict[str, Any]:
        safe: Dict[str, Any] = {}
        for key, value in arguments.items():
            text = redact_text(str(value))
            if len(text) > 120:
                text = text[:117] + "..."
            safe[key] = text
        return safe

    @staticmethod
    def _arguments_digest(arguments: Dict[str, Any]) -> str:
        try:
            payload = json.dumps(arguments, sort_keys=True, default=str)
        except Exception:
            payload = repr(arguments)
        return sha256(payload.encode("utf-8")).hexdigest()[:16]


class CurrentTimeTool(Tool):
    """Return the current date and time."""

    name = "current_time"
    description = "Return the current date and time in both local timezone and UTC."
    args_hint = "(no arguments)"
    capabilities = frozenset({"system:time"})

    def run(self, *, agent=None) -> str:  # type: ignore[override]
        local_now = datetime.now().astimezone()
        utc_now = datetime.now(timezone.utc)
        return "\n".join(
            [
                "Current time:",
                f"Local: {local_now.isoformat()}",
                f"UTC: {utc_now.isoformat()}",
            ]
        )


class DelegateTaskTool(Tool):
    """Bridge to the multi-agent orchestrator."""

    name = "delegate_task"
    description = (
        "Delegate a coding objective to external agents (Codex, Claude Code, Droid). "
        "Use this when the user requests non-trivial repository changes, refactors, test runs, "
        "or other tasks that benefit from automated coding agents."
    )
    args_hint = (
        "objective=<text> repo_path=/path/to/repo agents=[codex,claude-code] allow_dirty=false "
        "context={\"notes\":\"...\"}"
    )
    capabilities = frozenset({"filesystem", "process"})
    parameters_schema: Dict[str, Any] = {
        "type": "object",
        "properties": {
            "objective": {
                "type": "string",
                "description": "High-level description of the desired change.",
            },
            "repo_path": {
                "type": "string",
                "description": "Filesystem path to the git repository (defaults to current directory).",
            },
            "agents": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Optional ordered list of agent IDs to execute the task (e.g., codex, claude-code, droid).",
            },
            "allow_dirty": {
                "type": "boolean",
                "description": "Set true to run even when the working tree has local changes.",
            },
            "context": {
                "type": "object",
                "description": "Optional shared context injected into the orchestrator (JSON object).",
            },
        },
        "required": ["objective"],
        "additionalProperties": False,
    }

    def run(
        self,
        *,
        agent=None,
        objective: str,
        repo_path: Optional[str] = None,
        agents: Optional[List[str]] = None,
        allow_dirty: bool = False,
        context: Optional[Dict[str, Any]] = None,
    ) -> str:
        repo = Path(repo_path).expanduser() if repo_path else Path.cwd()
        if not repo.exists() or not repo.is_dir():
            raise ToolError(f"Repository path does not exist: {repo}")

        agent_ids: List[str] = []
        if agents:
            for entry in agents:
                if isinstance(entry, str) and entry.strip():
                    agent_ids.append(entry.strip())
                else:
                    raise ToolError("agents must be a list of agent IDs (strings)")
        if not agent_ids:
            agent_ids = ["codex"]

        task_id = f"chat-{uuid.uuid4().hex[:8]}"
        steps: List[StepSpec] = []
        for index, agent_id in enumerate(agent_ids, start=1):
            step = StepSpec(
                id=f"{task_id}-step-{index}",
                description=objective,
                agent_id=agent_id,
                inputs={
                    "repo_path": str(repo),
                    "allow_dirty": bool(allow_dirty),
                },
            )
            steps.append(step)

        shared_context: Dict[str, Any] = context or {}

        events: List[str] = []

        def _handle_event(event) -> None:
            etype = event.type
            payload = event.payload
            if etype == "task.started":
                events.append(f"[orchestrator] Task started: {payload.get('objective','')}")
            elif etype == "step.started":
                events.append(
                    f"[orchestrator] Step {payload.get('step_id')} started with agent {payload.get('agent_id')}: "
                    f"{payload.get('description','')}"
                )
            elif etype == "step.completed":
                events.append(
                    f"[orchestrator] Step {payload.get('step_id')} completed with status {payload.get('status')}: "
                    f"{payload.get('summary','')}"
                )
            elif etype == "step.skipped":
                events.append(
                    f"[orchestrator] Step {payload.get('step_id')} skipped: {payload.get('reason','')}"
                )
            elif etype == "task.completed":
                events.append(f"[orchestrator] Task completed with status {payload.get('status')}")

        orchestrator = Orchestrator(AgentFactory(), event_callback=_handle_event)
        task_spec = TaskSpec(
            id=task_id,
            objective=objective,
            steps=steps,
            shared_context=shared_context,
        )

        try:
            result = asyncio.run(orchestrator.run_task(task_spec))
        except Exception as exc:
            raise ToolError(f"Delegation failed: {exc}") from exc

        report_lines: List[str] = list(events)
        summary = f"Task {result.task_id} {'succeeded' if result.succeeded else 'failed'}."
        report_lines.append(summary)

        for step_result in result.step_results:
            header = f"- {step_result.step_id} ({step_result.status}): {step_result.summary}"
            report_lines.append(header)
            for artifact in step_result.artifacts:
                if artifact.kind == "patch" and artifact.content:
                    snippet = artifact.content.strip()
                    if len(snippet) > 2000:
                        snippet = snippet[:2000] + "\n... (truncated)"
                    report_lines.append("```diff\n" + snippet + "\n```")
            if step_result.logs:
                log_tail = [str(entry) for entry in step_result.logs[-5:]]
                report_lines.append("Logs:\n" + "\n".join(log_tail))

        return "\n".join(report_lines)


class WebSearchTool(Tool):
    """Web search with Crawl4AI-powered content extraction."""

    name = "web_search"
    description = "Search the web and extract clean content from results."
    args_hint = (
        "query (str, required); max_results (int, optional, default 3); domain (str, optional); "
        "titles_only (bool, optional); include_meta (bool, optional)"
    )
    capabilities = frozenset({"net:http", "net:crawl"})

    def __init__(self, *, session: Optional[requests.Session] = None) -> None:
        self._session = session or requests.Session()
        self._sync_crawler = None
        self._async_crawler_cls = None
        self._async_cache_mode = None
        self._init_crawler()

    def _init_crawler(self) -> None:
        """Detect available Crawl4AI backends."""
        try:
            from crawl4ai import WebCrawler  # type: ignore
        except Exception:
            WebCrawler = None  # type: ignore

        if WebCrawler:
            try:
                self._sync_crawler = WebCrawler(verbose=False)
            except Exception:
                self._sync_crawler = None

        if self._sync_crawler is None:
            try:
                from crawl4ai import AsyncWebCrawler, CacheMode  # type: ignore
            except Exception:
                self._async_crawler_cls = None
                self._async_cache_mode = None
            else:
                self._async_crawler_cls = AsyncWebCrawler
                self._async_cache_mode = CacheMode

    def run(
        self,
        *,
        agent=None,
        query: str,
        max_results: int = 3,
        domain: Optional[str] = None,
        titles_only: bool = False,
        include_meta: bool = False,
    ) -> str:  # type: ignore[override]
        query = query.strip()
        if not query:
            raise ToolError("web_search requires a non-empty 'query'")

        max_results = max(1, min(int(max_results or 3), 5))

        if domain:
            domain = domain.strip()
            if domain and f"site:{domain}" not in query:
                query = f"{query} site:{domain}"

        # Get search results from DuckDuckGo
        search_results = self._search_duckduckgo(query)
        if not search_results:
            return f"No results found for '{query}'."

        sources: List[Dict[str, str]] = []
        for result in search_results[:max_results]:
            snippet = (result.get("snippet") or "").strip()
            title = (result.get("title") or result.get("text") or "Result").strip()
            url = (result.get("url") or result.get("first_url") or "").strip()

            content = ""
            meta_description = ""
            if url:
                try:
                    content = self._crawl_content(url)
                except (ToolError, Exception) as exc:
                    try:
                        content = self._fetch_content_simple(url)
                    except Exception:
                        content = f"(content unavailable: {type(exc).__name__})"

            content = (content or "").strip()
            if content.startswith("(content unavailable") and snippet:
                content = ""

            if include_meta and url:
                try:
                    meta_description = self._fetch_meta_description(url)
                except Exception:
                    meta_description = ""

            sources.append(
                {
                    "title": title or "Result",
                    "url": url,
                    "snippet": snippet,
                    "content": content,
                    "meta": meta_description.strip(),
                }
            )

        header = f"Search summary for '{query}':"
        if titles_only:
            lines = [header]
            for idx, source in enumerate(sources[:max_results]):
                title = source.get("title") or "Result"
                url = source.get("url") or ""
                meta = source.get("meta") or ""
                line = f"{idx + 1}. {title}"
                if url:
                    line += f" ({url})"
                if include_meta and meta:
                    line += f" — {meta}"
                lines.append(line)
            return "\n".join(lines)

        summary = self._compose_takeaways(sources)
        details = self._compose_details(sources)

        parts = [header]
        if summary:
            parts.append(summary)
        if details:
            parts.append("")
            parts.append(details)
        return "\n".join([part for part in parts if part]).strip()

    def _crawl_content(self, url: str) -> str:
        """Extract content using Crawl4AI."""
        if not (self._sync_crawler or self._async_crawler_cls):
            raise ToolError("Crawl4AI not available")
        
        if self._sync_crawler is not None:
            return self._crawl_sync(url)
        return self._crawl_async(url)

    def _crawl_sync(self, url: str) -> str:
        try:
            result = self._sync_crawler.run(url=url, verbose=False, user_agent=USER_AGENT)
        except Exception as exc:  # pragma: no cover - library errors
            raise ToolError(f"Crawl4AI sync crawler failed: {exc}") from exc

        return self._render_crawl_result(result)

    def _crawl_async(self, url: str) -> str:
        if self._async_crawler_cls is None or self._async_cache_mode is None:
            raise ToolError("Crawl4AI async crawler unavailable")

        async def crawl_once() -> Any:
            async with self._async_crawler_cls(verbose=False, warning=False) as crawler:
                return await crawler.arun(
                    url=url,
                    cache_mode=self._async_cache_mode.BYPASS,
                    verbose=False,
                    user_agent=USER_AGENT,
                )

        result = self._run_coroutine(crawl_once())
        return self._render_crawl_result(result)

    @staticmethod
    def _run_coroutine(coro: Any) -> Any:
        if not asyncio.iscoroutine(coro):  # pragma: no cover - defensive
            return coro

        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(coro)

        result: list[Any] = []
        error: list[BaseException] = []

        def runner() -> None:
            try:
                result.append(asyncio.run(coro))
            except BaseException as exc:  # pragma: no cover - thread propagation
                error.append(exc)

        thread = threading.Thread(target=runner, daemon=True)
        thread.start()
        thread.join()

        if error:
            raise error[0]
        return result[0] if result else None

    def _render_crawl_result(self, result: Any) -> str:
        if result is None:
            raise ToolError("Crawl4AI returned no data")

        success = getattr(result, "success", False)
        if not success:
            message = getattr(result, "error_message", "unknown error")
            raise ToolError(f"Crawl4AI failed: {message}")

        candidates: List[str] = []

        markdown_v2 = getattr(result, "markdown_v2", None)
        if markdown_v2:
            for attr in ("fit_markdown", "markdown_with_citations", "raw_markdown"):
                value = getattr(markdown_v2, attr, None)
                if value:
                    candidates.append(str(value))

        markdown = getattr(result, "markdown", None)
        if isinstance(markdown, str):
            candidates.append(markdown)
        elif markdown:
            for attr in ("fit_markdown", "markdown_with_citations", "raw_markdown"):
                value = getattr(markdown, attr, None)
                if value:
                    candidates.append(str(value))

        for attr in ("extracted_content", "cleaned_html", "fit_html", "html"):
            value = getattr(result, attr, None)
            if value:
                candidates.append(str(value))

        for candidate in candidates:
            text = self._normalize_content(candidate)
            if text:
                return text[:1500]

        raise ToolError("Crawl4AI returned empty content")

    @staticmethod
    def _normalize_content(text: str) -> str:
        stripped = text.strip()
        if not stripped:
            return ""
        if "<" in stripped and ">" in stripped:
            stripped = re.sub(r"<[^>]+>", " ", stripped)
        stripped = re.sub(r"\s+", " ", stripped)
        return stripped


    def _search_duckduckgo(self, query: str) -> List[Dict[str, Any]]:
        """Fallback search using DuckDuckGo via jina.ai."""
        encoded = requests.utils.quote(query, safe="")
        url = f"https://r.jina.ai/https://duckduckgo.com/?q={encoded}&ia=web"
        try:
            response = self._session.get(url, timeout=8, headers={"User-Agent": USER_AGENT})
            if response.status_code >= 400:
                raise ToolError(f"DuckDuckGo returned status {response.status_code}")
            text = response.text.strip()
            if not text:
                raise ToolError("DuckDuckGo returned an empty response")
            results = self._parse_markdown_results(text)
            if not results:
                raise ToolError("No parsable results returned")
            return results
        except Exception as e:
            raise ToolError(f"DuckDuckGo search failed: {e}")

    def _parse_markdown_results(self, text: str) -> List[Dict[str, Any]]:
        results: List[Dict[str, Any]] = []
        pattern = re.compile(r"^(\d+)\.\s+(.*)")
        for line in text.splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            match = pattern.match(stripped)
            if not match:
                continue
            body = match.group(2).strip()
            if not body:
                continue
            if "###" in body:
                # Skip aggregated media sections
                continue
            clean_body = re.sub(r"!\[[^\]]*\]\([^)]+\)", "", body)
            url = self._extract_url(body)
            if not url:
                continue
            clean_body = re.sub(r"\[[^\]]*\]\([^)]+\)", "", clean_body)
            clean_body = re.sub(r"\s+", " ", clean_body).strip()
            clean_body = clean_body.replace("[]", "").strip()
            if not clean_body:
                continue
            if " " in clean_body:
                title, snippet = clean_body.split(" ", 1)
            else:
                title, snippet = clean_body, ""
            if not snippet or title.lower().startswith("more"):
                continue
            snippet = re.sub(r"\(https://duckduckgo\.com[^)]*\)\s*", "", snippet)
            snippet = snippet.strip()
            if not snippet:
                continue
            results.append({
                "title": title.strip(),
                "snippet": snippet.strip(),
                "url": url,
            })
        return results

    def _extract_url(self, body: str) -> str:
        for candidate in re.findall(r"https?://[^)\s]+", body):
            if "duckduckgo.com" in candidate or "external-content.duckduckgo.com" in candidate:
                continue
            return candidate
        site_match = re.search(r"site:([A-Za-z0-9.-]+)", body)
        if site_match:
            domain = site_match.group(1)
            if not domain.startswith("http"):
                return f"https://{domain}"
            return domain
        domain_match = re.match(r"([A-Za-z0-9.-]+)", body)
        if domain_match:
            domain = domain_match.group(1)
            if "." in domain:
                return f"https://{domain}"
        return ""

    def _fetch_content_simple(self, url: str) -> str:
        """Simple fallback content fetching."""
        if not url:
            raise ToolError("missing URL for content fetch")
        
        normalized = url if url.startswith(("http://", "https://")) else f"https://{url.lstrip('/')}"
        
        try:
            # Try jina.ai first
            go_url = f"https://r.jina.ai/{normalized}"
            response = self._session.get(go_url, timeout=5, headers={"User-Agent": USER_AGENT})
            if response.status_code < 400:
                text = response.text.strip()
                if text:
                    cleaned = self._normalize_content(text)
                    return cleaned[:1200]
        except Exception:
            pass
            
        try:
            # Fallback to direct fetch with simple HTML cleaning
            response = self._session.get(normalized, timeout=3, headers={"User-Agent": USER_AGENT})
            if response.status_code >= 400:
                raise ToolError(f"HTTP {response.status_code}")
            
            text = self._normalize_content(response.text)
            return text[:800]
        except Exception as e:
            raise ToolError(f"Content fetch failed: {e}")

    def _compose_takeaways(self, sources: List[Dict[str, str]]) -> str:
        sentences: List[str] = []
        for source in sources:
            snippet = source.get("snippet") or ""
            content = source.get("content") or ""
            for piece in (snippet, content):
                if not piece:
                    continue
                for sentence in self._extract_sentences(piece, limit=2):
                    sentences.append(sentence)
                    if len(sentences) >= 4:
                        break
                if len(sentences) >= 4:
                    break
            if len(sentences) >= 4:
                break
        if not sentences:
            return "No substantive information was retrieved."
        combined = " ".join(sentences)
        return combined[:600]

    def _compose_details(self, sources: List[Dict[str, str]]) -> str:
        detail_lines: List[str] = []
        for source in sources:
            url = source.get("url") or ""
            title = source.get("title") or "Result"
            snippet = source.get("snippet") or ""
            content = source.get("content") or ""
            meta = source.get("meta") or ""
            sentences: List[str] = []
            for piece in (snippet, content):
                if not piece:
                    continue
                remaining = max(0, 2 - len(sentences))
                if remaining == 0:
                    break
                sentences.extend(self._extract_sentences(piece, limit=remaining))
                if len(sentences) >= 2:
                    break
            if not sentences:
                continue
            detail = " ".join(sentences)
            detail = self._ensure_sentence(detail)
            if url:
                line = f"From {title} ({url}), {detail}"
            else:
                line = f"From {title}, {detail}"
            if meta:
                line += f" (meta: {meta})"
            detail_lines.append(line)
        return "\n\n".join(detail_lines)

    def _fetch_meta_description(self, url: str) -> str:
        try:
            response = self._session.get(url, timeout=4, headers={"User-Agent": USER_AGENT})
            if response.status_code >= 400:
                return ""
            html = response.text
        except Exception:
            return ""
        match = re.search(r'<meta[^>]+name=["\"]description["\"][^>]+content=["\"]([^"\"]+)["\"]', html, re.IGNORECASE)
        if match:
            return match.group(1).strip()
        match = re.search(r'<meta[^>]+content=["\"]([^"\"]+)["\"][^>]+name=["\"]description["\"]', html, re.IGNORECASE)
        if match:
            return match.group(1).strip()
        return ""

    @staticmethod
    def _extract_sentences(text: str, *, limit: int = 2) -> List[str]:
        if limit <= 0:
            return []
        if not text:
            return []
        cleaned = text.strip()
        if not cleaned:
            return []
        segments = re.split(r"(?<=[.!?])\s+", cleaned)
        sentences: List[str] = []
        for segment in segments:
            candidate = segment.strip()
            if not candidate:
                continue
            sentences.append(candidate)
            if len(sentences) >= limit:
                break
        return sentences

    @staticmethod
    def _ensure_sentence(text: str) -> str:
        trimmed = text.strip()
        if not trimmed:
            return ""
        if trimmed[-1] not in ".!?":
            return trimmed + "."
        return trimmed


class AlpacaAccountTool(Tool):
    """Fetch account, position, and order details from Alpaca Markets."""

    name = "alpaca_account"
    description = (
        "Retrieve account status, open positions, and recent orders from the Alpaca Markets trading API."
    )
    args_hint = (
        "order_status (str, optional, default 'open'); order_limit (int, optional, default 50); "
        "order_direction (str, optional, default 'desc')"
    )
    capabilities = frozenset({"net:http"})

    def __init__(
        self,
        *,
        session: Optional[requests.Session] = None,
        base_url: Optional[str] = None,
        timeout: float = 10.0,
    ) -> None:
        self._session = session or requests.Session()
        root = base_url or os.getenv("APCA_API_BASE_URL") or "https://paper-api.alpaca.markets"
        self._base_url = root.rstrip("/")
        self._timeout = max(timeout, 1.0)

    def run(
        self,
        *,
        agent=None,
        order_status: str = "open",
        order_limit: int = 50,
        order_direction: str = "desc",
    ) -> str:  # type: ignore[override]
        key_id = (os.getenv("APCA_API_KEY_ID") or "").strip()
        secret_key = (os.getenv("APCA_API_SECRET_KEY") or "").strip()
        if not key_id or not secret_key:
            raise ToolError("APCA_API_KEY_ID and APCA_API_SECRET_KEY must be set to use this tool")

        status = (order_status or "open").strip().lower()
        if status not in {"open", "closed", "all"}:
            raise ToolError("order_status must be one of: open, closed, all")

        direction = (order_direction or "desc").strip().lower()
        if direction not in {"asc", "desc"}:
            raise ToolError("order_direction must be 'asc' or 'desc'")

        try:
            limit = int(order_limit)
        except (TypeError, ValueError) as exc:
            raise ToolError("order_limit must be an integer between 1 and 500") from exc
        if not 1 <= limit <= 500:
            raise ToolError("order_limit must be between 1 and 500")

        headers = {
            "APCA-API-KEY-ID": key_id,
            "APCA-API-SECRET-KEY": secret_key,
            "Accept": "application/json",
            "User-Agent": USER_AGENT,
        }

        account = self._request_json("account", headers=headers)
        positions = self._request_json("positions", headers=headers)
        orders = self._request_json(
            "orders",
            headers=headers,
            params={"status": status, "limit": limit, "direction": direction},
        )

        lines: List[str] = ["Alpaca Account Overview:"]
        lines.extend(self._summarize_account(account))
        lines.append("")
        lines.extend(self._summarize_positions(positions))
        lines.append("")
        lines.extend(self._summarize_orders(orders, status, direction, limit))

        return "\n".join(lines).strip()

    def _request_json(
        self,
        endpoint: str,
        *,
        headers: Dict[str, str],
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        url = f"{self._base_url}/v2/{endpoint.lstrip('/')}"
        try:
            response = self._session.get(
                url,
                headers=headers,
                params=params,
                timeout=self._timeout,
            )
        except requests.RequestException as exc:
            raise ToolError(f"Failed to reach Alpaca API: {exc}") from exc
        if response.status_code >= 400:
            detail = self._extract_error_detail(response)
            raise ToolError(f"Alpaca API error ({response.status_code}): {detail}")
        try:
            return response.json()
        except ValueError as exc:
            raise ToolError("Alpaca API returned malformed JSON") from exc

    @staticmethod
    def _extract_error_detail(response: requests.Response) -> str:
        try:
            payload = response.json()
        except ValueError:
            text = (response.text or "").strip()
            return text or "no additional details"
        if isinstance(payload, dict):
            for key in ("message", "error", "detail"):
                value = payload.get(key)
                if value:
                    return str(value)
        if isinstance(payload, str):
            return payload
        try:
            return json.dumps(payload)
        except Exception:
            return "unrecognized error response"

    @staticmethod
    def _summarize_account(account: Any) -> List[str]:
        if not isinstance(account, dict):
            return ["Status: unavailable"]

        lines: List[str] = []
        fields = [
            ("Status", str(account.get("status") or "").upper()),
            ("Account Number", account.get("account_number")),
            ("Currency", account.get("currency")),
            ("Cash", account.get("cash")),
            ("Buying Power", account.get("buying_power")),
            ("Portfolio Value", account.get("portfolio_value")),
            ("Last Equity", account.get("last_equity")),
        ]
        for label, value in fields:
            if value in (None, ""):
                continue
            lines.append(f"{label}: {value}")

        blocks: List[str] = []
        if account.get("trading_blocked"):
            blocks.append("trading")
        if account.get("transfers_blocked"):
            blocks.append("transfers")
        if account.get("account_blocked"):
            blocks.append("account")
        if blocks:
            lines.append(f"Blocks: {', '.join(blocks)}")
        return lines or ["Status: unknown"]

    @staticmethod
    def _summarize_positions(positions: Any) -> List[str]:
        items = positions if isinstance(positions, list) else []
        lines: List[str] = [f"Open Positions ({len(items)}):"]
        if not items:
            lines.append("  (none)")
            return lines
        for position in items[:25]:
            symbol = position.get("symbol") or "?"
            qty = position.get("qty") or position.get("quantity") or "0"
            side = (position.get("side") or "").lower()
            header = f"- {symbol}: {qty}"
            if side:
                header += f" {side}"
            lines.append(header)

            details: List[str] = []
            avg_price = position.get("avg_entry_price")
            if avg_price:
                details.append(f"avg {avg_price}")
            current_price = position.get("current_price")
            if current_price:
                details.append(f"last {current_price}")
            market_value = position.get("market_value")
            if market_value:
                details.append(f"mv {market_value}")
            unrealized_pl = position.get("unrealized_pl")
            unrealized_plpc = position.get("unrealized_plpc")
            if unrealized_pl or unrealized_plpc:
                pl_parts: List[str] = []
                if unrealized_pl:
                    pl_parts.append(str(unrealized_pl))
                if unrealized_plpc:
                    pl_parts.append(AlpacaAccountTool._format_percent(unrealized_plpc))
                details.append("P/L " + " ".join(pl_parts))
            if details:
                lines.append(f"  {'; '.join(details)}")
        remaining = len(items) - 25
        if remaining > 0:
            lines.append(f"  … {remaining} more position(s) not shown")
        return lines

    @staticmethod
    def _summarize_orders(
        orders: Any,
        status: str,
        direction: str,
        limit: int,
    ) -> List[str]:
        items = orders if isinstance(orders, list) else []
        lines: List[str] = [f"Recent Orders [status={status}, direction={direction}, limit={limit}] ({len(items)}):"]
        if not items:
            lines.append("  (none)")
            return lines

        for order in items[:limit]:
            timestamp = order.get("created_at") or order.get("submitted_at") or ""
            side = (order.get("side") or "").upper()
            qty = order.get("qty") or order.get("quantity") or order.get("notional") or ""
            symbol = order.get("symbol") or "?"
            order_type = order.get("type") or order.get("order_type") or ""
            status_text = order.get("status") or ""

            parts: List[str] = ["-"]
            if timestamp:
                parts.append(timestamp)
            if side:
                parts.append(side)
            if qty:
                parts.append(str(qty))
            parts.append(symbol)
            if order_type:
                parts.append(order_type)
            line = " ".join(part for part in parts if part).strip()
            if status_text:
                line += f" -> {status_text}"
            lines.append(line)

            detail_parts: List[str] = []
            limit_price = order.get("limit_price")
            if limit_price:
                detail_parts.append(f"limit {limit_price}")
            stop_price = order.get("stop_price") or order.get("stop_loss")
            if stop_price:
                detail_parts.append(f"stop {stop_price}")
            filled_qty = order.get("filled_qty") or order.get("filled_quantity")
            if filled_qty:
                detail_parts.append(f"filled {filled_qty}")
            avg_fill_price = order.get("filled_avg_price")
            if avg_fill_price:
                detail_parts.append(f"avg {avg_fill_price}")
            order_id = order.get("id") or order.get("order_id")
            if order_id:
                detail_parts.append(f"id {order_id}")
            if detail_parts:
                lines.append(f"  {', '.join(detail_parts)}")

        if len(items) > limit:
            lines.append(f"  … {len(items) - limit} additional order(s) not shown")
        return lines

    @staticmethod
    def _format_percent(value: Any) -> str:
        try:
            pct = float(value) * 100.0
        except (TypeError, ValueError):
            return str(value)
        return f"{pct:.2f}%"


class ReadFileTool(Tool):
    """Read text from files on disk."""

    name = "read_file"
    description = "Read a UTF-8 text file with optional offset/length and filtering."  # noqa: RUF015
    args_hint = (
        "path (str, required); offset (int, optional); length (int, optional); "
        "max_lines (int, optional); pattern (str, optional); case_sensitive (bool, optional)"
    )
    capabilities = frozenset({"fs:read"})

    def __init__(self, *, max_chars: int = DEFAULT_FILE_CHUNK) -> None:
        self._max_chars = max_chars

    def run(
        self,
        *,
        agent=None,
        path: str,
        offset: int = 0,
        length: Optional[int] = None,
        max_lines: Optional[int] = None,
        pattern: Optional[str] = None,
        case_sensitive: bool = False,
    ) -> str:  # type: ignore[override]
        resolved = _resolve_user_path(path)
        if not resolved.is_file():
            raise ToolError(f"not a file: {resolved}")

        safe_offset = max(int(offset or 0), 0)
        chunk_limit = None if length is None else max(int(length), 0)
        max_read = self._max_chars if chunk_limit is None else chunk_limit

        try:
            with resolved.open("r", encoding="utf-8", errors="replace") as handle:
                handle.seek(safe_offset)
                data = handle.read(max_read + 1 if chunk_limit is None else max_read)
        except Exception as exc:
            raise ToolError(f"failed to read {resolved}: {exc}") from exc

        truncated = False
        if chunk_limit is None and len(data) > self._max_chars:
            data = data[: self._max_chars]
            truncated = True

        filtered = data

        if max_lines is not None:
            safe_lines = max(int(max_lines), 0)
            if safe_lines and safe_lines < len(filtered.splitlines()):
                filtered = "\n".join(filtered.splitlines()[:safe_lines])
                truncated = True

        highlight_note = ""
        if pattern:
            try:
                flags = 0 if case_sensitive else re.IGNORECASE
                regex = re.compile(pattern, flags)
            except re.error as exc:
                raise ToolError(f"invalid regex pattern: {exc}") from exc

            def _repl(match: re.Match[str]) -> str:
                return f"<<{match.group(0)}>>"

            highlighted = regex.sub(_repl, filtered)
            if highlighted != filtered:
                highlight_note = f"(pattern highlighted with <<>> markers: {pattern})"
            filtered = highlighted

        lines = [f"File: {resolved}"]
        lines.append("")
        lines.append(filtered)
        if highlight_note:
            lines.append(f"\n{highlight_note}")
        if truncated:
            lines.append(f"\n(truncated output)")
        return "\n".join(lines)


class WriteFileTool(Tool):
    """Write text content to disk."""

    name = "write_file"
    description = "Create or update a text file; requires explicit overwrite/append."  # noqa: RUF015
    args_hint = (
        "path (str, required); content (str, required); overwrite (bool, optional); "
        "append (bool, optional); create_dirs (bool, optional); atomic (bool, optional); "
        "preserve_times (bool, optional); show_diff (bool, optional)"
    )
    capabilities = frozenset({"fs:write"})

    def run(
        self,
        *,
        agent=None,
        path: str,
        content: str,
        overwrite: bool = False,
        append: bool = False,
        create_dirs: bool = False,
        atomic: bool = False,
        preserve_times: bool = False,
        show_diff: bool = False,
    ) -> str:  # type: ignore[override]
        if append and overwrite:
            raise ToolError("set either append or overwrite, not both")
        if atomic and append:
            raise ToolError("atomic writes are incompatible with append mode")

        resolved = _resolve_user_path(path)
        parent = resolved.parent
        if not parent.exists():
            if create_dirs:
                try:
                    parent.mkdir(parents=True, exist_ok=True)
                except Exception as exc:
                    raise ToolError(f"failed to create parent directories: {exc}") from exc
            else:
                raise ToolError(f"parent directory does not exist: {parent}")

        if resolved.exists() and not resolved.is_file():
            raise ToolError(f"path exists and is not a file: {resolved}")

        if resolved.exists() and not (overwrite or append):
            raise ToolError("file exists; set overwrite=True or append=True")

        old_stat = None
        old_content = ""
        if resolved.exists():
            try:
                old_stat = resolved.stat()
                old_content = resolved.read_text(encoding="utf-8")
            except Exception:
                old_content = ""

        final_content = content
        if append:
            final_content = (old_content or "") + content
            try:
                with resolved.open("a", encoding="utf-8") as handle:
                    handle.write(content)
            except Exception as exc:
                raise ToolError(f"failed to append {resolved}: {exc}") from exc
        else:
            if atomic:
                tmp_path = None
                try:
                    with tempfile.NamedTemporaryFile(
                        "w",
                        encoding="utf-8",
                        delete=False,
                        dir=str(parent),
                    ) as tmp:
                        tmp.write(content)
                        tmp_path = Path(tmp.name)
                    if tmp_path is not None:
                        if old_stat is not None:
                            try:
                                tmp_path.chmod(old_stat.st_mode)
                            except Exception:
                                pass
                        else:
                            try:
                                tmp_path.chmod(0o644)
                            except Exception:
                                pass
                        os.replace(tmp_path, resolved)
                except Exception as exc:
                    if tmp_path and tmp_path.exists():
                        tmp_path.unlink(missing_ok=True)
                    raise ToolError(f"failed to write {resolved} atomically: {exc}") from exc
            else:
                try:
                    with resolved.open("w", encoding="utf-8") as handle:
                        handle.write(content)
                except Exception as exc:
                    raise ToolError(f"failed to write {resolved}: {exc}") from exc

        if preserve_times and old_stat and resolved.exists():
            try:
                os.utime(resolved, (old_stat.st_atime, old_stat.st_mtime))
            except Exception:
                pass

        diff_text = ""
        if show_diff:
            before = old_content.splitlines()
            after = final_content.splitlines()
            diff_lines = list(
                difflib.unified_diff(
                    before,
                    after,
                    fromfile="before",
                    tofile="after",
                    lineterm="",
                )
            )
            if diff_lines:
                diff_text = "\n".join(diff_lines)

        action = "Appended" if append else "Wrote"
        result_lines = [f"{action} {len(content)} characters to {resolved}"]
        if preserve_times and old_stat:
            result_lines.append("Preserved original timestamps")
        if diff_text:
            result_lines.append("\nDiff:\n" + diff_text)
        return "\n".join(result_lines)


class ShellCommandTool(Tool):
    """Execute shell commands on the local system."""

    name = "shell_command"
    description = "Run a shell command and return stdout/stderr."  # noqa: RUF015
    args_hint = (
        "command (str, required); timeout (int, optional); cwd (str, optional); "
        "sudo (bool, optional); interactive (bool, optional); retries (int, optional)"
    )
    capabilities = frozenset({"process:exec"})

    def run(
        self,
        *,
        agent=None,
        command: str,
        timeout: int = 60,
        cwd: Optional[str] = None,
        sudo: bool = False,
        interactive: bool = False,
        retries: int = 0,
    ) -> str:  # type: ignore[override]
        cmd = (command or "").strip()
        if not cmd:
            raise ToolError("shell_command requires a non-empty 'command'")

        resolved_cwd: Optional[str] = None
        if cwd:
            path = Path(cwd).expanduser()
            if not path.exists():
                raise ToolError(f"cwd does not exist: {path}")
            if not path.is_dir():
                raise ToolError(f"cwd is not a directory: {path}")
            resolved_cwd = str(path)

        safe_timeout = max(1, int(timeout or 0))

        base_cmd: List[str] = ["/bin/bash", "-lc", cmd]
        if sudo:
            sudo_path = shutil.which("sudo")
            if not sudo_path:
                raise ToolError("sudo requested but not available on PATH")
            base_cmd = [sudo_path, "-n"] + base_cmd

        attempts = max(1, int(retries) + 1)
        stdout = ""
        stderr = ""
        exit_code = 0

        for attempt in range(attempts):
            try:
                if interactive:
                    exit_code, stdout = self._run_interactive(base_cmd, resolved_cwd, safe_timeout)
                    stderr = ""
                else:
                    completed = subprocess.run(
                        base_cmd,
                        capture_output=True,
                        text=True,
                        timeout=safe_timeout,
                        cwd=resolved_cwd,
                    )
                    exit_code = completed.returncode
                    stdout = (completed.stdout or "").strip()
                    stderr = (completed.stderr or "").strip()
            except subprocess.TimeoutExpired as exc:
                if attempt < attempts - 1:
                    continue
                raise ToolError(f"command timed out after {safe_timeout}s") from exc
            except FileNotFoundError as exc:
                raise ToolError("/bin/bash not found on system") from exc
            except Exception as exc:  # pragma: no cover - defensive
                if attempt < attempts - 1:
                    time.sleep(0.1)
                    continue
                raise ToolError(f"command failed: {exc}") from exc

            if exit_code == 0 or attempt == attempts - 1:
                break

        lines = [f"$ {cmd}"]
        if resolved_cwd:
            lines.append(f"(cwd: {resolved_cwd})")
        lines.append(f"attempts: {attempt + 1}")
        if sudo:
            lines.append("sudo: enabled")
        if interactive:
            lines.append("interactive: captured pseudo-tty session")
        if stdout:
            lines.append("\nstdout:\n" + stdout)
        if stderr:
            lines.append("\nstderr:\n" + stderr)
        lines.append(f"\nexit_code: {exit_code}")

        output = "\n".join(lines).strip()
        if len(output) > MAX_SHELL_OUTPUT:
            output = output[: MAX_SHELL_OUTPUT - 20] + "\n(truncated)"
        return output

    def _run_interactive(
        self,
        cmd: List[str],
        cwd: Optional[str],
        timeout: int,
    ) -> tuple[int, str]:
        master, slave = pty.openpty()
        start = time.monotonic()
        proc = subprocess.Popen(
            cmd,
            stdin=slave,
            stdout=slave,
            stderr=slave,
            cwd=cwd,
            text=False,
            close_fds=True,
        )
        os.close(slave)
        chunks: List[str] = []
        try:
            while True:
                if timeout and (time.monotonic() - start) > timeout:
                    proc.kill()
                    raise subprocess.TimeoutExpired(cmd, timeout)
                r, _, _ = select.select([master], [], [], 0.1)
                if master in r:
                    try:
                        data = os.read(master, 1024)
                    except OSError:
                        break
                    if not data:
                        break
                    chunks.append(data.decode(errors="replace"))
                if proc.poll() is not None and not r:
                    break
            while True:
                try:
                    data = os.read(master, 1024)
                except OSError:
                    break
                if not data:
                    break
                chunks.append(data.decode(errors="replace"))
        finally:
            os.close(master)
        proc.wait()
        return proc.returncode, "".join(chunks).strip()


class ListDirectoryTool(Tool):
    """List entries in a directory."""

    name = "list_dir"
    description = "List directory contents (non-recursive)."
    args_hint = (
        "path (str, optional, default '.'); show_hidden (bool, optional); max_entries (int, optional); "
        "recursive (bool, optional); depth (int, optional); human (bool, optional)"
    )
    capabilities = frozenset({"fs:read"})

    def run(
        self,
        *,
        agent=None,
        path: str = ".",
        show_hidden: bool = False,
        max_entries: int = 100,
        recursive: bool = False,
        depth: Optional[int] = None,
        human: bool = False,
    ) -> str:  # type: ignore[override]
        resolved = _resolve_user_path(path)
        if resolved.is_file():
            resolved = resolved.parent
        if not resolved.exists():
            raise ToolError(f"directory does not exist: {resolved}")
        if not resolved.is_dir():
            raise ToolError(f"not a directory: {resolved}")

        limit = max(int(max_entries or 0), 0) or 100

        max_depth = None if depth is None else max(0, int(depth))

        lines = [f"Directory: {resolved}"]
        collected: List[str] = []

        def _human_size(value: int) -> str:
            units = ["B", "KB", "MB", "GB", "TB"]
            size = float(value)
            for unit in units:
                if size < 1024 or unit == units[-1]:
                    return f"{size:.1f}{unit}" if unit != "B" else f"{int(size)}B"
                size /= 1024
            return f"{value}B"

        def _format_entry(entry: Path) -> str:
            suffix = "/" if entry.is_dir() else ""
            if not human:
                return entry.name + suffix
            try:
                size = entry.stat().st_size if entry.is_file() else sum(
                    child.stat().st_size for child in entry.iterdir() if child.is_file()
                ) if entry.is_dir() else 0
            except Exception:
                size = 0
            size_text = _human_size(size)
            return f"{entry.name + suffix} ({size_text})"

        def _walk(current: Path, current_depth: int = 0, prefix: str = "") -> None:
            nonlocal collected
            try:
                entries = sorted(current.iterdir(), key=lambda item: item.name.lower())
            except Exception as exc:
                collected.append(prefix + f"<error: {exc}>")
                return
            for entry in entries:
                if not show_hidden and entry.name.startswith('.'):
                    continue
                collected.append(prefix + _format_entry(entry))
                if len(collected) >= limit:
                    return
                if recursive and entry.is_dir() and not entry.is_symlink():
                    if max_depth is None or current_depth < max_depth:
                        _walk(entry, current_depth + 1, prefix + "  ")
                        if len(collected) >= limit:
                            return

        _walk(resolved, 0, "" if not recursive else "")

        if not collected:
            lines.append("(empty)")
            return "\n".join(lines)

        lines.extend(collected)
        if len(collected) >= limit:
            lines.append("... limit reached")
        return "\n".join(lines)


class _BrowserToolBase(Tool):
    capabilities = frozenset({"net:http", "browser:automation"})

    def __init__(self, session_resolver):
        self._session_resolver = session_resolver

    def _session(self, agent) -> BrowserSession:
        if agent is None:
            raise ToolError("browser tool requires agent context")
        session = self._session_resolver(agent)
        if session is None:
            raise ToolError("browser session unavailable")
        return session


class BrowserSearchTool(_BrowserToolBase):
    name = "browser.search"
    description = "Federated web search with persistent browsing state."
    args_hint = "query (str); topn (int); sources (list[str]); time_range (str); site (str); budget_tokens (int)"
    parameters_schema = {
        "type": "object",
        "properties": {
            "query": {"type": "string"},
            "topn": {"type": "integer", "minimum": 1},
            "sources": {"type": "array", "items": {"type": "string"}},
            "time_range": {"type": "string"},
            "site": {"type": "string"},
            "budget_tokens": {"type": "integer", "minimum": 256},
        },
        "required": ["query"],
        "additionalProperties": False,
    }

    def run(self, *, agent=None, **kwargs: Any) -> str:  # type: ignore[override]
        session = self._session(agent)
        query = (kwargs.get("query") or "").strip()
        if not query:
            raise ToolError("browser.search requires 'query'")
        topn = int(kwargs.get("topn") or os.getenv("ATLAS_SEARCH_TOPN", DEFAULT_TOPN))
        sources = kwargs.get("sources")
        time_range = kwargs.get("time_range")
        site = kwargs.get("site")
        budget = int(kwargs.get("budget_tokens") or DEFAULT_BUDGET)
        result = session.search(
            query=query,
            topn=topn,
            sources=sources,
            time_range=time_range,
            site=site,
            budget_tokens=budget,
        )
        return result["pageText"]


class BrowserOpenTool(_BrowserToolBase):
    name = "browser.open"
    description = "Open a search result or scroll the current page."
    args_hint = "id (int|str); cursor (int); loc (int); num_lines (int)"
    parameters_schema = {
        "type": "object",
        "properties": {
            "id": {"oneOf": [{"type": "integer"}, {"type": "string"}]},
            "cursor": {"type": "integer"},
            "loc": {"type": "integer"},
            "num_lines": {"type": "integer", "minimum": -1},
        },
        "additionalProperties": False,
    }

    def run(self, *, agent=None, **kwargs: Any) -> str:  # type: ignore[override]
        session = self._session(agent)
        result = session.open(
            id=kwargs.get("id"),
            cursor=int(kwargs.get("cursor", -1)),
            loc=int(kwargs.get("loc", -1)),
            num_lines=int(kwargs.get("num_lines", -1)),
        )
        return result["pageText"]


class BrowserFindTool(_BrowserToolBase):
    name = "browser.find"
    description = "Find text within the current browser page."
    args_hint = "pattern (str); cursor (int)"
    parameters_schema = {
        "type": "object",
        "properties": {
            "pattern": {"type": "string"},
            "cursor": {"type": "integer"},
        },
        "required": ["pattern"],
        "additionalProperties": False,
    }

    def run(self, *, agent=None, **kwargs: Any) -> str:  # type: ignore[override]
        session = self._session(agent)
        pattern = (kwargs.get("pattern") or "").strip()
        if not pattern:
            raise ToolError("browser.find requires 'pattern'")
        result = session.find(pattern=pattern, cursor=int(kwargs.get("cursor", -1)))
        return result["pageText"]

if "__all__" not in globals():
    __all__: List[str] = []
__all__ += [
    "BrowserSearchTool",
    "BrowserOpenTool",
    "BrowserFindTool",
    "DelegateTaskTool",
    "AlpacaAccountTool",
]
